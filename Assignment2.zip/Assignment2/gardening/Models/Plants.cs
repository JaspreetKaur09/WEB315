using System;
using System.ComponentModel.DataAnnotations;

namespace gardening.Models
{
    public class Plants
    {
        public string plantName {get;set; }
        public string scientificName {get;set;}
        public string soiltype {get;set;}
        public int temperature{get;set;}

        [DataType(DataType.Date)]
        public DateTime DateiBuy {get; set;}
        public decimal Price {get; set;}
        
        
        
    }
}
        
        
        
        

